import javax.security.sasl.SaslClient;
import java.util.Scanner;

public class SinglyLinkedList {
    //Represent a node of the singly linked list
    class Node {
        String data;
        Node next;

        public Node(String data) {
            this.data = data;
            this.next = null;
        }
    }

    //Represent the head and tail of the singly linked list
    public Node head = null;
    public Node tail = null;

    //addNode() will add a new node to the list
    public void addNode(String data) {
        //Create a new node
        Node newNode = new Node(data);

        //Checks if the list is empty
        if (head == null) {
            //If list is empty, both head and tail will point to new node
            head = newNode;
            tail = newNode;
        } else {
            //newNode will be added after tail such that tail's next will point to newNode
            tail.next = newNode;
            //newNode will become new tail of the list
            tail = newNode;
        }
    }

    //display() will display all the nodes present in the list
    public void display() {
        //Node current will point to head
        Node current = head;

        if (head == null) {
            System.out.println("List is empty");
            return;
        }
        System.out.println("Nodes of singly linked list: " + "\n" + "--------------------------------");
        while (current != null) {
            //Prints each node by incrementing pointer
            System.out.print(current.data + " ");
            current = current.next;
        }
        System.out.println();
    }

    public void reversing() {
        // initializing next, curr and prev node
        Node prev = null;
        Node next = null;
        Node current = head;
        // going through the list until current is null
        while (current != null) {
            // assigning 2 position node to next
            next = current.next;
            // set null in 2 node
            current.next = prev;
            // current(head) is assign to previous node
            prev = current;
            // 2 position node assign to current
            current = next;
        }
        // assign previous node as head of pointer
        head = prev;
    }

    // Going through the list and find that car is available or not
    public void find(String carName) {

        Boolean searchStatus = false;
        Node current = head;
        while (current != null) {
            if (current.data.equalsIgnoreCase(carName)) {
                searchStatus  = true;
                System.out.println(carName + " is in a list");
                break;
            } else {
                // going to next node until searched car is founded
                current = current.next;
            }
        }
        // warn user if item is missing in a list
        if(!searchStatus){
            System.out.println(carName + " is not in a list");
        }
    }

    // Adding new element in a list
    public Node addFirst(){
        // Use of scanner class to find the car you want
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter name of car to add in a list: ");
        Node newNode =  new Node(sc.next());
        newNode.next = head;
        head = newNode;
        return newNode;
    }

    // Deleting last element present in a list
    public Node deleteLast() {
        Node current = head;
        if (current == null || current.next == null) {  // checking that is there any item available in list
            head = null;
            return current;
        }
        Node nextNode = current.next;   // creating new node to keep track of next node
        while (current.next != null) {
            if (nextNode.next == null) {
                current.next = null;
            }
            current = nextNode;
            nextNode = nextNode.next;
        }
        return current;
    }

    public static void main(String[] args) {
        // instantiating the singlylinkedlist
        SinglyLinkedList sList = new SinglyLinkedList();

        //Add nodes to the list
        sList.addNode("BMW");
        sList.addNode("Ford");
        sList.addNode("Hyundai");
        sList.addNode("Mercedes");
        sList.addNode("Tesla");
        sList.addNode("Toyota");
        sList.addNode("Honda");
        sList.addNode("Kia");
        sList.addNode("Nissan");
        sList.addNode("Citroen");

        // Use of Menu/option to increase user interaction
        Scanner sc = new Scanner(System.in);
        System.out.println();
        System.out.println("-----*------> LinkList Portfolio By Afnan Ahmed <-----*------");

        // Using while loop to check option is in a range or not
        while (true) {

            System.out.println("\n1.Display All items available in a list / updated list" +
                    "\n2.Searching For a car" +
                    "\n3.Deleting last item in a list" +
                    "\n4.Adding the item in a list" +
                    "\n5.Reversing a list" +
                    "\n6.Exit");
            System.out.println("\n-> Enter your choice \n");
            String option = sc.next();

            switch (option) {
                case "1" : {
                    // Displaying current and updated list
                        sList.display();
                    break;
                }
                case "2" : {
                    System.out.print("Enter car name: ");
                    sList.find(sc.next());
                    break;
                }
                case "3" : {
                    sList.deleteLast();
                    System.out.print("SUCCESSFULLY DELETED! please press 1 to see updated list \n");
                    break;
                }
                case "4" : {
                    sList.addFirst();
                    System.out.print("SUCCESSFULLY ADDED! please press 1 to see updated list \n");
                    break;
                }
                case "5" : {
                    sList.reversing();
                    System.out.print("SUCCESSFULLY REVERSED! please press 1 to see updated list \n");
                    break;
                }
                case "6" : {
                    System.out.println("Thank you for testing");
                    System.exit(0);
                    break;
                } default:
                    System.out.println("----> Something went wrong :( ");
            }
        }
    }
}